<template>
  <div class="Footer">
    <img src="../../../static/images/Footer.png"/>
  </div>
</template>

<script>
export default {
  name: 'Index',
  data () {
    return {
    }
  }
}
</script>

<style scoped>
.Footer {
  width: 100%;
  height: 3rem;
  background: rgba(24, 121, 185, 0.8);
}
.Footer img {
  height: 1.2rem;
  margin-top: 0.7rem;
}
</style>
