const state = {
  hasLogin: false,
  projectId: ''
}

export default state
