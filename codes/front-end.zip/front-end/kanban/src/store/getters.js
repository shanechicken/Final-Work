const hasLogin = state => state.hasLogin
const projectId = state => state.projectId

export default { hasLogin, projectId }
